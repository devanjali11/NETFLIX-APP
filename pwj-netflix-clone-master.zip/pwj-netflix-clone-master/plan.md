Dec 3, 2020
- Keep the user logged in
- Create a Register Page
- Complete the API for Registration

Nov 26, 2020

- Create a Login Form 
- Grab the data
- Hash a password
- Keep the user logged in 



CREATE LOGIN FO NETFLIX CLONE

October 29

- Fix the issue with the iframe
- Add genres to netflix clone

--- Grab all genre titles and loop though them
--- Use the same API as we used before
--- Grab the movies for each genre

October 22

- Show the trailer for the user when they select a movie
- Find a way to grab the movie (YouTube, Movie Database API, IMDB)
- If we can't find the trailer, we need to Tell The user "Can't find trailer"
- Open a modal on click of a movie
- Disable user interation
- Show the movie in the modal (LOAD youtube video)
- Show background black


October 1

- Horizontal scroll for movies DONE
- Retreive the other movies from the API DONE
- Add the hover effect to individual movies 
- PARTY in the house



- Create a Header
- Finish up the movies section
- Understand Promises, APIs, Fetch..
- Pull in movies from API







- Create HTML Structure -> DONE
- Create header -> DONE
- Style header
- Create featured section
- Create Netflix Originals
- Create Movies List
- Create Trending now
- Technology: HTML, JS CSS
- Icons: font awesome